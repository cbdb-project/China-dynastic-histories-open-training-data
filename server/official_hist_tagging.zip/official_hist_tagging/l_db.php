<?php
$db = "official_hist_tagging";
$usr = "root";
$pw = "";
$host = "localhost";
$link = mysqli_connect($host, $usr, $pw, $db);
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>