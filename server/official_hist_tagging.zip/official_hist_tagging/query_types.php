<?php
include_once("query_names.php");

function find_type_name_by_id($id){
    $sql = "SELECT `name` FROM data_type WHERE id = ? ORDER BY id";
    $name = query_name($id, $sql, "name");
    return $name;
}

function find_subtype_name_by_id($id){
    $sql = "SELECT `name` FROM data_subtype WHERE id = ? ORDER BY id";
    $name = query_name($id, $sql, "name");
    return $name;
}

?>