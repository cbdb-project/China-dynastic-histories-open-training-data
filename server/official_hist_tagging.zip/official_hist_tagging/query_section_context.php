<?php
include_once("query_names.php");
function query_section_context($section_id){
    include("db.php");
    $sql_for_utf8 = "set names 'utf8'";
    $stmt = $link->prepare($sql_for_utf8);
    $stmt->execute();
    $sql = "SELECT * FROM sections WHERE id>? AND id<?";
    $stmt = $link->prepare($sql);
    $id_begin = $section_id-4;
    if ($id_begin<0){
        $id_begin = 0;
    }
    $id_end = $section_id+3;
    $stmt->bind_param("ii", $id_begin, $id_end);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    $output = [];
    if ($result->num_rows<1){
        exit();
    }
    $output = "";
    while ($row = $result->fetch_assoc()) {
        $output.=$row["text"];
    }
    return $output;
    // echo $output;
}

?>