<?php
header("Access-Control-Allow-Origin: *");
include("db.php");
$chapter_id = $_GET["chapter_id"];
$sql_for_utf8 = "set names 'utf8'";
$stmt = $link->prepare($sql_for_utf8);
$stmt->execute();
$sql = "SELECT DISTINCT main.biog_subject_id as id, main.biog_subject_name FROM main INNER JOIN sections ON main.section_id=sections.id WHERE chapter_id = ? UNION DISTINCT SELECT DISTINCT main.content_personid as id, main.content_person_name FROM main INNER JOIN sections ON main.section_id=sections.id WHERE chapter_id = ? AND main.content_personid IS NOT NULL AND content_personid != 0 ORDER BY id";
$stmt = $link->prepare($sql);
$stmt->bind_param("ii", $chapter_id, $chapter_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
$output = [];
while ($row = $result->fetch_assoc()) {
    array_push($output,$row["id"]."-".$row["biog_subject_name"]);
}
echo json_encode($output);
?>