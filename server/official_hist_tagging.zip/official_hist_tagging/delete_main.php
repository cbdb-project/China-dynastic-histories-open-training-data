<?php
header("Access-Control-Allow-Origin: *");
include("db.php");
include_once("query_types.php");
$tag_id = $_GET["tag_id"];
$sql = "set names 'utf8'";
$stmt = $link->prepare($sql);
$stmt->execute();
$sql = "DELETE FROM `main` WHERE id=?";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $tag_id);
$stmt->execute();
$stmt->close();
?>