<?php
header("Access-Control-Allow-Origin: *");
include("db.php");
include_once("query_types.php");
$chapter_id = $_GET["chapter_id"];
$sql = "set names 'utf8'";
$stmt = $link->prepare($sql);
$stmt->execute();
$sql = "SELECT chapters.chapter_name, chapters.book_id, chapters.book_name FROM chapters WHERE id = ?";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $chapter_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
$output = [];
if ($result->num_rows<1){
    $stmt->close();
    exit();
}
while ($row = $result->fetch_assoc()) {
    $book_id = $row["book_id"];
    $book_name = $row["book_name"];
    $chapter_name = $row["chapter_name"];
}
$output = array("book_id" => $book_id, 
                "book_name" => $book_name,
                "chapter_id" => $chapter_id,
                "chapter_name" => $chapter_name);
$sql = "SELECT id AS section_id, text, chapter_id, biog_subject_id, biog_subject_name FROM `sections` WHERE chapter_id = ?";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $chapter_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
if ($result->num_rows<1){
    exit();
}

// work on each section
$sections = [];
while ($row = $result->fetch_assoc()) {
    $section_id = $row["section_id"];
    $text = $row["text"];
    $biog_subject_id = $row["biog_subject_id"];
    $biog_subject_name = $row["biog_subject_name"];
    $single_section = array("section_id" => $section_id,
                            "section_text" => $text,
                            "biog_subject_id" => $biog_subject_id,
                            "biog_subject_name" => $biog_subject_name);
    $sql = "SELECT * FROM `main` WHERE `section_id` = ?";
    $stmt = $link->prepare($sql);
    $stmt->bind_param("i", $section_id);
    $stmt->execute();
    $result_tags = $stmt->get_result();
    $stmt->close();
    if ($result_tags->num_rows<1){
        $single_section["tag_records"] = [];
    }else{
        $tag_records = [];
        // work on each tags
        while ($row = $result_tags->fetch_assoc()) {
            $single_tag_records = array("tag_id"=>$row["id"],
                                    "biog_subject_id"=>$row["biog_subject_id"], 
                                    "biog_subject_name"=>$row["biog_subject_name"],
                                    "type"=>$row["type"],
                                    "type_chn"=>find_type_name_by_id($row["type"]),
                                    "subtype"=>$row["subtype"],
                                    "subtype_chn"=>find_subtype_name_by_id($row["subtype"]),
                                    "content"=>$row["content"],
                                    "content_refined"=>$row["content_refined"],
                                    "content_personid"=>$row["content_personid"],
                                    "content_person_name"=>$row["content_person_name"]);
            array_push($tag_records, $single_tag_records);
        }
        $single_section["tag_records"] = $tag_records;
    }
    array_push($sections, $single_section);
}
$output["sections"] = $sections;
echo json_encode($output)
?>