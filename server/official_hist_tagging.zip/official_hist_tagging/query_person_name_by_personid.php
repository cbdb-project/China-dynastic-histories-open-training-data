<?php
header("Access-Control-Allow-Origin: *");
$person_id = $_GET["person_id"];
$url = "https://input.cbdb.fas.harvard.edu/basicinformation/".$person_id;
$json = file_get_contents($url);
$obj = json_decode($json);
echo json_encode($obj->{"c_name_chn"});
?>