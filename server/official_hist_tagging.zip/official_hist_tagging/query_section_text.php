<?php
include_once("query_names.php");
// if (!function_exists(query_name)){
//     require("query_names.php");
// }

function find_section_text_by_id($id){
    $sql = "SELECT `text` FROM sections WHERE id = ?";
    $name = query_name($id, $sql, "text");
    return $name;
}

?>