<?php
function query_name($id, $sql, $field_name){
    include("db.php");
    $sql_for_utf8 = "set names 'utf8'";
    $stmt = $link->prepare($sql_for_utf8);
    $stmt->execute();
    $stmt = $link->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    $output = [];
    if ($result->num_rows<1){
        exit();
    }
    $row = $result->fetch_assoc();
    return $row[$field_name];
}
?>