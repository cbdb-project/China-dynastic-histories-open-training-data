<?php
header("Access-Control-Allow-Origin: *");
include("db.php");
include_once("query_types.php");
include_once("query_section_text.php");
include_once("query_section_context.php");
$tag_id = $_GET["tag_id"];
$sql = "set names 'utf8'";
$stmt = $link->prepare($sql);
$stmt->execute();
$sql = "SELECT * FROM main WHERE id=?";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $tag_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
$output = [];
while ($row = $result->fetch_assoc()) {
    $section_id = $row["section_id"];
    $single_tag_records = array("section_id"=>$section_id,
                                "section_text"=>find_section_text_by_id($section_id),
                                "section_context"=>query_section_context($section_id),
                                "tag_id"=>$row["id"],
                                "biog_subject_id"=>$row["biog_subject_id"], 
                                "biog_subject_name"=>$row["biog_subject_name"],
                                "type"=>$row["type"],
                                "type_chn"=>find_type_name_by_id($row["type"]),
                                "subtype"=>$row["subtype"],
                                "subtype_chn"=>find_subtype_name_by_id($row["subtype"]),
                                "content"=>$row["content"],
                                "content_refined"=>$row["content_refined"],
                                "content_personid"=>$row["content_personid"],
                                "content_person_name"=>$row["content_person_name"]);
}
if(isset($single_tag_records)){
    echo json_encode($single_tag_records);
}else{
    echo json_encode("no records");
}

?>