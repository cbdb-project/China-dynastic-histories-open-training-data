<?php
header("Access-Control-Allow-Origin: *");
include("db.php");
include_once("query_types.php");
$tag_id = $_GET["tag_id"];
$biog_subject_id = $_GET["biog_subject_id"];
$biog_subject_name = $_GET["biog_subject_name"];
$type = $_GET["type"];
$subtype = $_GET["subtype"];
$content = $_GET["content"];
$content_refined = $_GET["content_refined"];
$content_personid = $_GET["content_personid"];
$content_person_name = $_GET["content_person_name"];
if ($content_personid == ""){
    $content_personid = NULL;
    $content_person_name = NULL;
}
$date = date("Ymd");
$sql = "set names 'utf8'";
$stmt = $link->prepare($sql);
$stmt->execute();
$sql = "UPDATE `main` SET
`biog_subject_id` = ?,
`biog_subject_name` = ?,
`type` = ?,
`subtype` = ?,
`content` = ?,
`content_refined` = ?,
`content_personid` = ?,
`content_person_name` = ?,
`date` = ?
WHERE id = ?";
$stmt = $link->prepare($sql);
$stmt->bind_param("isiississi", $biog_subject_id, $biog_subject_name, $type, $subtype, $content, $content_refined, $content_personid, $content_person_name, $date, $tag_id);
$stmt->execute();
$stmt->close();
?>