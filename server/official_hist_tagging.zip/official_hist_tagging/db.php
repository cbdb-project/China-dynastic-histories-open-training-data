<?php
$db = "xxx";
$usr = "xxx";
$pw = "xxx";
$host = "localhost";
$link = mysqli_connect($host, $usr, $pw, $db);
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>