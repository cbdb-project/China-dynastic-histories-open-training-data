<?php
header("Access-Control-Allow-Origin: *");
include("db.php");
$sql_for_utf8 = "set names 'utf8'";
$stmt = $link->prepare($sql_for_utf8);
$stmt->execute();
$typeid = $_GET["typeid"];
$sql = "SELECT `id`,`name` FROM data_subtype WHERE `type_id` = ? ORDER BY id";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $typeid);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
$output = [];
while ($row = $result->fetch_assoc()) {
    array_push($output,$row["id"]."-".$row["name"]);
}
echo json_encode($output);
?>