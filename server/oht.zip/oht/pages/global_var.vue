<script type="text/javascript">
    const url = 'http://127.0.0.1'
    export default {
        url,
    }
</script>